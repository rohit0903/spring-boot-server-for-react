spring boot 2.x
spring rest
spring security
jwt
authentication
authorization(3 roles - admin, user, mod)
mysql
hibernate/jpa
java 1.8
----------------------------------------------
Taken from Bezcoder.
----------------------------------------------

UI : https://github.com/rohit0903/react-jwt-auth
BE : 
	Change in BE:
		Modify Authorization in code to X-Access-Token
		Return headerAuth instead of headerAuth.substring(.........)